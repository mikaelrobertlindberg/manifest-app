# Tacksamhet Font Demo

## 🎨 Font Alternativ för Mysigare Känsla

Demo sida som visar 10 olika fonter applicerade på Tacksamhet appens interface:

1. **Poppins** - Friendly & Modern 
2. **Nunito** - Warm & Gentle ⭐ (Rekommenderad för mindfulness)
3. **Source Sans Pro** - Clean & Readable
4. **Lato** - Humanist & Approachable 
5. **Montserrat** - Elegant & Sophisticated
6. **Open Sans** - Neutral & Friendly
7. **Roboto** - Modern & Geometric
8. **Raleway** - Elegant & Thin
9. **Playfair Display** - Luxury & Serif (för premium känsla)
10. **Inter** - Current Font (Reference)

## 🚀 Deployment

Öppna `index.html` i browser för att se alla font-exempel side by side.
